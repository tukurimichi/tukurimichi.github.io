﻿つくるみち 壁紙セット vol.3「石鹸」

01_soap_dish           ソープディッシュの朝
02_five_colors         色違いの整列
03_bubbles             泡
04_droplets            水滴
05_wrapped             ラッピング
06_worn_down           丸くなった
07_bath                湯船
08_last_and_next       使い切りと予備

サイズ: 1536 x 2752 (スマートフォン向け)
個人利用の範囲で自由にお使いください。再配布・販売はご遠慮ください。

tukurimichi.com
#AIに一万円渡してみた
